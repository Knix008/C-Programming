#!/bin/bash
TEMPLATE_DIR=${CPPUTEST_HOME}/scripts/templates
source ${CPPUTEST_HOME}/scripts/GenerateSrcFiles.sh ClassNameCIoDriver c NoMock $1 $2

