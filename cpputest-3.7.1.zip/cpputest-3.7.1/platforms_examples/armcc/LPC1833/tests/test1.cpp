﻿#include "CppUTest/TestHarness.h"

TEST_GROUP(start)
{
};

TEST(start, first)
{
    FAIL("Start here!");
}
