/*
 ============================================================================
 Name        : BinaryToDecimalwithCPUTicksExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>

#if defined(__GNUC__) && (defined(__MINGW32__) || defined( __MING64__))
static inline uint64_t get_cpu_cycle(void) {
	uint64_t ticks;

	__asm volatile("rdtsc" : "=A"(ticks));
	return ticks;
}
#elif defined(_MSC_BUILD)
#include <intrin.h>
#pragma intrinsic( __rdtsc)
static inline uint64_t get_cpu_cycle(void) {
	return __rdtsc();
}
#elif defined(__APPLE__)
static inline uint64_t get_cpu_cycle(void) {
	uint64_t ticks;

	__asm volatile("rdtsc" : "=A"(ticks));
	return ticks;
}
#endif

int decimal_convert(char* binary) {
	unsigned int size = 0;
	unsigned int value = 0;
	int i, j;

	/* Check input binary */
	if (binary == NULL) {
		printf("Cannot convert NULL binary pointer!!!\n");
		return -1;
	}
	/* Get the size of binary value array */
	size = strlen(binary);
	/* Convert binary into decimal */
	for (i = size - 1, j = 0; i >= 0; i--, j++) {
		if (binary[i] == '1') {
			value += 1 << j;
		} else if (binary[i] == '0') {
			/* Do nothing */
			continue;
		} else {
			/* Not a binary value */
			return -1;
		}
	}
	return value;
}

void print_timetick_count(uint64_t input) {
#if defined(__GNUC__) && (defined(__MINGW32__) || defined( __MING64__))
	printf("The time tick counter : %I64d\n", input);
#elif defined(_MSC_BUILD)
	printf("The time tick counter : %I64d\n", input);
#elif defined(__APPLE__)
	printf("The time tick counter : %" PRIu64 "\n", input);
#endif
}

int main(void) {
	puts("Binary To Decimal Convert Example 01"); /* prints Binary To Decimal Convert Example 01 */
	char *input[] = { "1101", "1", "0", "01", "10", "11", "0101", "11011011",
			"3101" };
	unsigned int size = sizeof(input) / sizeof(input[0]);
	unsigned int i;
	uint64_t before, after, elapsed;

	before = get_cpu_cycle();
	print_timetick_count(before);
	for (i = 0; i < size; i++) {
		printf("The decimal value of %12s --> %5d\n", input[i],
				decimal_convert(input[i]));
	}
	after = get_cpu_cycle();
	print_timetick_count(after);
	elapsed = after - before;
	print_timetick_count(elapsed);
	printf("Done!!!\n");
	return EXIT_SUCCESS;
}
