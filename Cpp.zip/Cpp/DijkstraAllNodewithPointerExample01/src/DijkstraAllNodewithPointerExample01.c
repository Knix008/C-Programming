/*
 ============================================================================
 Name        : DijkstraAllNodewithPointerExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define INF UINT_MAX

typedef struct EDGE {
	unsigned int node;
	unsigned int weight;
	struct EDGE *next;
} EDGE_T;

typedef struct NODE {
	int node;
	struct EDGE *edge;
} NODE_T;

void print_graph(NODE_T *graph, unsigned int size) {
	EDGE_T *edge;
	unsigned int i;

	for (i = 0; i < size; i++) {
		edge = graph->edge;
		if (edge == NULL) {
			printf("The node %d has no edge.\n", i);
			graph++;
			continue;
		}
		while (edge != NULL) {
			printf("The node %d --> %d : %d\n", i, edge->node, edge->weight);
			edge = edge->next;
		}
		graph++;
	}
	return;
}

void print_distance(unsigned int *distance, unsigned int size) {
	unsigned int i;

	if (distance == NULL) {
		return;
	}
	printf("----------------------------------------\n");
	printf("Distance : ");
	for (i = 0; i < size; i++) {
		if (distance[i] == INF) {
			printf(" INF");
			continue;
		}
		printf("%3d", distance[i]);
	}
	printf("\n----------------------------------------\n");
	return;
}

void print_set(unsigned int *set, unsigned int size) {
	unsigned int i;

	printf("Set : ");
	for (i = 0; i < size; i++) {
		printf(" %d", set[i]);
	}
	printf("\n");
	return;
}

void print_path(unsigned int *path, unsigned int size) {
	unsigned int i;

	printf("-----------------------------------------\n");
	printf("Path : ");
	for (i = 0; i < size; i++) {
		if (path[i] != -1) {
			printf("%3d ", path[i]);
		}
	}
	printf("\n-----------------------------------------\n");
}

static inline unsigned int *allocate_distance(unsigned int size) {
	unsigned int *distance = NULL;

	if ((distance = (unsigned int *) malloc(sizeof(unsigned int) * size))
			== NULL) {
		printf("Cannot allocate memory for distance data!!!\n");
		exit(-1);
	}
	memset(distance, INF, sizeof(unsigned int) * size);
	return distance;
}

static inline unsigned int *allocate_set(unsigned int size) {
	unsigned int *set;

	if ((set = (unsigned int *) malloc(sizeof(unsigned int) * size)) == NULL) {
		printf("Cannot allocate memory for visited marking set!!!\n");
		exit(-1);
	}
	memset(set, 0, sizeof(unsigned int) * size);
	return set;
}

static inline NODE_T *allocate_graph( size) {
	NODE_T *graph = NULL;

	if ((graph = (NODE_T *) malloc(sizeof(NODE_T) * size)) == NULL) {
		printf("Cannot allocate memory for nodes!!!\n");
		exit(-1);
	}
	return graph;
}

static inline EDGE_T *allocate_edge(void) {
	EDGE_T *edge = NULL;

	if ((edge = (EDGE_T *) malloc(sizeof(EDGE_T))) == NULL) {
		printf("Cannot allocate memory for edges!!!\n");
		exit(-1);
	}
	return edge;
}

static unsigned int array_index;
static inline unsigned int *allocate_path(unsigned int size) {
	unsigned int *path;

	if ((path = (unsigned int *) malloc(sizeof(unsigned int) * size)) == NULL) {
		printf("Cannot allocate memory for distance data!!!\n");
		exit(-1);
	}
	memset(path, -1, sizeof(unsigned int) * size);
	array_index = 0;
	return path;
}

static inline void set_path(unsigned int *path, unsigned int node) {
	path[array_index] = node;
	array_index++;
	return;
}

NODE_T *make_graph(int *input, unsigned int size) {
	NODE_T *graph = NULL;
	NODE_T *node = NULL;
	EDGE_T **edge = NULL;
	unsigned int i, j, weight;

	/* Allocate graph*/
	graph = allocate_graph(size);
	/* Set first node */
	node = graph;
	/* Initialize all node */
	for (i = 0; i < size; i++) {
		node->edge = NULL;
		node->node = i;
		edge = &(node->edge);
		/* Make edge linked list */
		for (j = 0; j < size; j++) {
			/* Get weight */
			weight = *((input + i * size) + j);
			/* Not itself and not INF */
			if ((weight != INF) && (weight != 0)) {
				(*edge) = allocate_edge();
				(*edge)->node = j;
				(*edge)->weight = weight;
				(*edge)->next = NULL;
				edge = &((*edge)->next);
			}
		}
		/* Go next node */
		node++;
	}
	return graph;
}

static inline unsigned int isEmpty(unsigned int *set, unsigned int size) {
	unsigned int i = 0;

	for (i = 0; i < size; i++) {
		/* Not empty */
		if (set[i] != 1) {
			return 0;
		}
	}
	/* Empty */
	return 1;
}

static inline unsigned int get_shortest_path(unsigned int *distance,
		unsigned int *set, unsigned int size) {

	unsigned int i;
	unsigned int min_distance = INF;
	unsigned int node = 0;

	for (i = 0; i < size; i++) {
		if ((distance[i] < min_distance) && (set[i] == 0)) {
			min_distance = distance[i];
			node = i;
		}
	}
	return node;
}

static inline unsigned int *init_distance_map(unsigned int *distance,
		EDGE_T *edge) {
	while (edge != NULL) {
		distance[edge->node] = edge->weight;
		edge = edge->next;
	}
	return distance;
}

static inline void update_distance(unsigned int *distance, unsigned int *set,
		unsigned int node, EDGE_T *edge) {
	if (set[edge->node] == 0) {
		if (distance[node] + edge->weight < distance[edge->node]) {
			distance[edge->node] = distance[node] + edge->weight;
		}
	}
}

unsigned int isAllNodeVisited(unsigned int *set, unsigned int *path,
		unsigned int node) {
	if (node != 0) {
		set[node] = 1;
		set_path(path, node);
		return 0;
	}
	return 1;
}

void free_all(unsigned int *set, unsigned int *path) {
	free(set);
	free(path);
	return;
}

unsigned int *dijkstra(NODE_T *graph, unsigned size, unsigned int start) {
	unsigned int *distance;
	unsigned int *set;
	unsigned int *path;
	EDGE_T *edge;
	unsigned int node;

	/* Allocate needed memory */
	distance = allocate_distance(size);
	set = allocate_set(size);
	path = allocate_path(size);
	/* Initialize search */
	distance[start] = 0;
	set[start] = 1;
	set_path(path, start);

	/* Initialize distance map for start node */
	distance = init_distance_map(distance, graph[start].edge);

	/* Find shortest path( weight ) from start to each node */
	while (!isEmpty(set, size)) {
		node = get_shortest_path(distance, set, size);
		/* Check all node visited. If not then mark visited */
		if (isAllNodeVisited(set, path, node)) {
			break;
		}
		/* Get adjacent edges */
		edge = graph[node].edge;
		while (edge != NULL) {
			update_distance(distance, set, node, edge);
			edge = edge->next;
		}
	}
	print_path(path, size);
	/* Free all allocated data structures.*/
	free(set);
	free(path);
	return distance;
}

int main(void) {
	int input[][5] = { { 0, 4, 1, INF, INF }, { INF, 0, INF, INF, 4 }, {
	INF, 2, 0, 4, INF }, { INF, INF, INF, 0, 4 }, { INF, INF, INF, INF, 0 } };
	unsigned int size = sizeof(input) / sizeof(input[0]);
	NODE_T *graph = NULL;
	unsigned int *distance;

	puts("Dijkstra Example 03"); /* prints Dijkstra Example 03 */
	graph = make_graph(input[0], size);
	print_graph(graph, size);

	distance = dijkstra(graph, size, 0);
	print_distance(distance, size);
	free(distance);

	distance = dijkstra(graph, size, 1);
	print_distance(distance, size);
	free(distance);

	distance = dijkstra(graph, size, 2);
	print_distance(distance, size);
	free(distance);

	distance = dijkstra(graph, size, 3);
	print_distance(distance, size);
	free(distance);

	distance = dijkstra(graph, size, 4);
	print_distance(distance, size);
	free(distance);

	return EXIT_SUCCESS;
}

