/*
 ============================================================================
 Name        : HeaderExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "header.h"

struct mystruct {
	int age;
	char *name;
};

MYSTRUCT *function_A(MYSTRUCT* mystruct )
{
	puts("Function A Called!!!");
	return NULL;
}

int main(void) {
	puts("Header File Example 01"); /* prints Header File Example 01 */
	function_A( NULL );

	return EXIT_SUCCESS;
}
