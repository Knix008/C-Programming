#ifndef __HEADER_H__
#define __HEADER_H__

typedef struct mystruct MYSTRUCT;

#endif
