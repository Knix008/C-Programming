/*
 ============================================================================
 Name        : SimpleArithmaticOperation.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int x = 1;
	int y = 2;
	int z = 3;

	puts("Simple Arithmetic Operation Example 01"); /* prints Simple Arithmetic Operation Example 01 */
	x = (x++) + y - z;
	printf("%d\n", x);

	x = 1;
	y = 2;
	z = 3;
	x = x + y - z;
	x++;
	printf("%d\n", x);

	return EXIT_SUCCESS;
}
