/*
 ============================================================================
 Name        : BinaryToDecimalConvertExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int decimal_convert(char* binary) {
	unsigned int size = 0;
	unsigned int value = 0;
	int i, j;

	/* Check input binary */
	if (binary == NULL) {
		printf("Cannot convert NULL binary pointer!!!\n");
		return -1;
	}
	/* Get the size of binary value array */
	size = strlen(binary);
	/* Convert binary into decimal */
	for (i = size - 1, j = 0; i >= 0; i--, j++) {
		if (binary[i] == '1') {
			value += 1 << j;
		}
	}
	return value;
}

int main(void) {
	puts("Binary To Decimal Convert Example 01"); /* prints Binary To Decimal Convert Example 01 */
	char *input[] = { "1101", "1", "0", "01", "10", "11", "0101" };
	unsigned int size = sizeof(input) / sizeof(input[0]);
	unsigned int i;

	for (i = 0; i < size; i++) {
		printf("The decimal value of %8s --> %d\n", input[i],
				decimal_convert(input[i]));
	}
	printf("Done!!!\n");
	return EXIT_SUCCESS;
}
