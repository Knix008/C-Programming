/*
 * ManageInfo.h
 *
 *  Created on: 2017. 8. 10.
 *      Author: shkwon
 */

#ifndef MANAGEINFO_H_
#define MANAGEINFO_H_

void do_manage_info(void);

#endif /* MANAGEINFO_H_ */
