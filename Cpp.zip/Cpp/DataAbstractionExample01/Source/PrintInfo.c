/*
 * PrintInfo.c
 *
 *  Created on: 2017. 8. 10.
 *      Author: shkwon
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct info {
	unsigned int age;
	unsigned int height;
} INFO;

INFO *create_info(unsigned int age, unsigned int height) {
	INFO *info;

	if ((info = (INFO *) malloc(sizeof(INFO))) == NULL) {
		return NULL;
	}
	info->age = age;
	info->height = height;
	return info;
}

void print_info(INFO *info) {
	printf("Age : %d\n", info->age);
	printf("Height : %d\n", info->height);
	return;
}

void delete_info(INFO *info) {
	free(info);
	info = NULL;
	return;
}
