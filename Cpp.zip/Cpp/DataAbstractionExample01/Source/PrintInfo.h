/*
 * PrintInfo.h
 *
 *  Created on: 2017. 8. 10.
 *      Author: shkwon
 */

#ifndef PRINTINFO_H_
#define PRINTINFO_H_

typedef struct info INFO;

INFO *create_info(unsigned int age, unsigned int height);
void print_info(INFO *info);
void delete_info(INFO *info);

#endif /* PRINTINFO_H_ */
