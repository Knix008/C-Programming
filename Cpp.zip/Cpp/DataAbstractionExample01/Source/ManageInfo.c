/*
 * ManageInfo.c
 *
 *  Created on: 2017. 8. 10.
 *      Author: shkwon
 */

#include <stdio.h>

#include "PrintInfo.h"
#include "ManageInfo.h"

void do_manage_info(void) {
	INFO *info = NULL;

	info = create_info(47, 185);
	print_info(info);
	delete_info(info);
	return;
}
