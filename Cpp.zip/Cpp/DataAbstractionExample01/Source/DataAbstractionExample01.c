/*
 ============================================================================
 Name        : DataAbstractionExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "ManageInfo.h"

int main(void) {
	puts("Data Type Abstraction Example 01"); /* prints Data Type Abstraction Example 01 */

	do_manage_info();

	return EXIT_SUCCESS;
}
