/*
 ============================================================================
 Name        : DecimalToBinaryConvertExample01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_BINARY_ARRAY_SIZE 100
char binary[MAX_BINARY_ARRAY_SIZE];

char* binary_convert(int input) {
	unsigned int count = 0;
	char* result = NULL;

	/* Check input is 0? */
	if (input == 0) {
		binary[0] = 0;
		count = 1;
	} else {
		/* Convert decimal value to binary integer in each position */
		for (int i = 0; (i < MAX_BINARY_ARRAY_SIZE) && (input > 0); i++) {
			binary[i] = input % 2;
			input = input / 2;
			count++;
		}
	}
	/* Allocate memory for reversing the temporary converted value */
	if ((result = (char*) malloc(sizeof(char) * count + 1)) == NULL) {
		printf("Cannot allocate memory for binary value!!!\n");
		return NULL;
	}
	/* Reverse */
	for (int i = count - 1, j = 0; (i >= 0) && (j < count); i--, j++) {
		result[j] = binary[i] + '0';
	}
	/* Mark end of string */
	result[count] = '\0';
	return result;
}

#define NUMBER 1024

int main() {
	char* result = NULL;
	unsigned int i;

	for (i = 0; i <= NUMBER; i++) {
		result = binary_convert(i);
		if (result != NULL) {
			printf("The decimal value %5d --> binary value : %12s\n", i,
					result);
			free(result);
		} else {
			printf("Cannot convert %5d to binary value!!!\n", i);
		}
	}
	return 0;
}

