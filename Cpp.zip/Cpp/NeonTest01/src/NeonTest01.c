/*
 ============================================================================
 Name        : NeonTest01.c
 Author      : Suho Kwon
 Version     :
 Copyright   : Copyrights@2016, 2017
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	puts("Neon Test Example 01"); /* prints Neon Test Example 01 */
	return EXIT_SUCCESS;
}
